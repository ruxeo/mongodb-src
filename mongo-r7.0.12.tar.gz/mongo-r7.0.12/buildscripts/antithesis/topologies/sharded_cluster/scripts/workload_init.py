"""Script to initialize a workload container in Antithesis."""
from time import sleep

while True:
    sleep(10)
