"""Global flags used by resmoke."""

import threading

HANG_ANALYZER_CALLED = threading.Event()
